// Export pages
export '/home/home_page/home_page_widget.dart' show HomePageWidget;
export '/details/details_widget.dart' show DetailsWidget;
export '/upload/upload_page/upload_page_widget.dart' show UploadPageWidget;
export '/picture_page/picture_page_widget.dart' show PicturePageWidget;
export '/user/food_list/food_list_widget.dart' show FoodListWidget;
export '/user/dashboard/dashboard_widget.dart' show DashboardWidget;
export '/open_ai_vision_a_p_i/home_page_1/home_page1_widget.dart'
    show HomePage1Widget;
