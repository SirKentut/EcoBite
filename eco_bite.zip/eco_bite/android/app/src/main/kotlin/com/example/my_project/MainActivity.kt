package com.mycompany.ecobite

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
